cd framework-solve/solve && cargo build-bpf
cd ..
cargo r --release
